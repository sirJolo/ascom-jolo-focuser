#ifndef _JoloAccelStepper_h
#define _JoloAccelStepper_h

#include "AccelStepper.h"

class JoloAccelStepper : public AccelStepper
{
    public:
    JoloAccelStepper(uint8_t interface = AccelStepper::FULL4WIRE, uint8_t pin1 = 2, uint8_t pin2 = 3, uint8_t pin3 = 4, uint8_t pin4 = 5, bool enable = true);
    
    protected:
    void step0(long step);
    
};


JoloAccelStepper::JoloAccelStepper(uint8_t interface, uint8_t pin1, uint8_t pin2, uint8_t pin3, uint8_t pin4, bool enable)
{
    AccelStepper::AccelStepper(interface, pin1, pin2, pin3, pin4, enable);
}

void JoloAccelStepper::step0(long step)
{
    //hahha
}


#endif
