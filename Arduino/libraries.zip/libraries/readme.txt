For information on installing libraries, see: http://arduino.cc/en/Guide/Libraries


328
Timer 0 - PWM 5, 6
Timer 1 - PWM 9, 10
Timer 2 - PWM 3, 11