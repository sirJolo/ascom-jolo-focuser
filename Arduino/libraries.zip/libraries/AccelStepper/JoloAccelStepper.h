#ifndef _JoloAccelStepper_h
#define _JoloAccelStepper_h

#include "AccelStepper.h"

class JoloAccelStepper : public AccelStepper
{
    public:
    JoloAccelStepper(uint8_t interface = AccelStepper::FULL4WIRE, uint8_t pin1 = 2, uint8_t pin2 = 3, uint8_t pin3 = 4, uint8_t pin4 = 5, bool enable = true);
    
    protected:
    void step0(long step);
	void setOutputPins(uint8_t mask);
    
};


JoloAccelStepper::JoloAccelStepper(uint8_t interface, uint8_t pin1, uint8_t pin2, uint8_t pin3, uint8_t pin4, bool enable)
{
    AccelStepper::AccelStepper(interface, pin1, pin2, pin3, pin4, enable);
}

void JoloAccelStepper::step0(long step)
{
    switch (step & 0x3)
    {
	case 0:    // 1010
	    setOutputPins(0b1110);
	    break;

	case 1:    // 0110
	    setOutputPins(0b1101);
	    break;

	case 2:    //0101
	    setOutputPins(0b1011);
	    break;

	case 3:    //1001
	    setOutputPins(0b0111);
	    break;
    }
}

// You might want to override this to implement eg serial output
// bit 0 of the mask corresponds to _pin[0]
// bit 1 of the mask corresponds to _pin[1]
// ....
void JoloAccelStepper::setOutputPins(uint8_t mask)
{
    uint8_t numpins = 2;
    if (_interface == FULL4WIRE || _interface == HALF4WIRE || _interface == FUNCTION) numpins = 4;
    uint8_t i;
    for (i = 0; i < numpins; i++) digitalWrite(_pin[i], (mask & (1 << i)) ? (HIGH ^ _pinInverted[i]) : (LOW ^ _pinInverted[i]));
}


#endif
